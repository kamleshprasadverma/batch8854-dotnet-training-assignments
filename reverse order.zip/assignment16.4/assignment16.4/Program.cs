﻿using System;

namespace assignment16._4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, t, sum = 0;
            int r;
            Console.Write("Input a number: ");
            num = Convert.ToInt32(Console.ReadLine());

            for (t = num; t != 0; t = t / 10)
            {
                r = t % 10;
                sum = sum * 10 + r;
            }
            Console.Write("The number in reverse order is : {0} \n", sum);
        }
    }
}

