﻿using System;

namespace assignment16._5
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, Octal = 0, dn;
            Console.Write("Enter the Decimal Number : ");
            dn = Convert.ToInt32(Console.ReadLine());
            i = 1;
            for (j = dn; j > 0; j = j / 8)
            {
                Octal = Octal + (j % 8) * i;
                i *= 10;
                dn /= 8;
            }
            Console.WriteLine("The Octal Number is {1}.\n\n", dn, Octal);
            Console.ReadKey();
        }
    }
}
