﻿using System;

namespace Assignment16._2
{
    class Program
    {
        static void Main(string[] args)
        {

            {
                bool Prime = true;
                Console.WriteLine("Prime Numbers between 1 to 50 : ");
                for (int a = 2; a <= 50; a++)
                {
                    for (int b = 2; b <= 50; b++)
                    {
                        if (a != b && a % b == 0)
                        {
                            Prime = false;
                            break;
                        }
                    }
                    if (Prime)
                    {
                        Console.Write("\n" + a);
                    }
                    Prime = true;
                }
                Console.ReadKey();
            }
        }
    }
}
    

