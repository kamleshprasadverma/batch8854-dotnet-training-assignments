﻿using System;

namespace assignment16._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, ctr;
            Console.Write("Input number of terms : ");
            ctr = Convert.ToInt32(Console.ReadLine());
            // for (i = 1; i <= ctr; i++)
            //{
            i = ctr * ctr * ctr;
                //Console.Write("Number is : {0} and cube of the {1} is :{2} \n", i, i, (i * i * i));
                Console.Write("cube of the nuber is : \n", i);
            //}
        }
    }
}
